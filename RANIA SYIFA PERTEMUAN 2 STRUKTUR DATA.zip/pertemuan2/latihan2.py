"""
2. Diberikan sebuah tuple data mahasiswa:
mahasiswa = ("A001", "Budi", "Informatika")
1. Tampilkan nama mahasiswa dari tuple tersebut.
2. Tampilkan seluruh isi tuple menggunakan perulangan for.
3. Jelaskan satu alasan mengapa tuple tidak bisa diubah.
"""
#tampilkan nama mahasiswa
mahasiswa = ("A001", "Budi", "Informatika")
print(mahasiswa[1])

#menggunakan perulangan for
for x in mahasiswa:
    print (x)

"""
tuple tidak bisa diubah karena yang bisa diubah itu adalah list
"""




